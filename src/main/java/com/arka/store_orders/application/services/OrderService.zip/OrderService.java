package com.arka.store_orders.application.services;

import com.arka.store_orders.application.factory.OrderFactory;
import com.arka.store_orders.domain.models.Order;
import com.arka.store_orders.domain.models.OrderItem;
import com.arka.store_orders.domain.models.OrderStatus;
import com.arka.store_orders.domain.ports.in.OrderUseCases;
import com.arka.store_orders.domain.ports.out.feignclient.PaymentPort;
import com.arka.store_orders.domain.ports.out.feignclient.ProductPort;
import com.arka.store_orders.domain.ports.out.persistence.OrderPersistencePort;

import com.arka.store_orders.infrastructure.resources.Request.OrderRequest;
import com.arka.store_orders.infrastructure.resources.Request.PaymentRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OrderService implements OrderUseCases {

    private final OrderItemService itemService;
    private final OrderFactory orderFactory;
    private final OrderPersistencePort persistence;
    private final ProductPort productPort;
    private final PaymentPort paymentPort;
    @Override
    public Order createOrder(OrderRequest request) {
        Order newOrder=orderFactory.createOrder(request);
        for(OrderItem item : newOrder.getItems()){
            productPort.reserveStock(item.getProductSku(), item.getQuantity());
            item.calculateAmount();
        }
        newOrder.calculateTotal();
        return persistence.save(newOrder);
    }
    @Override
    public Order processOrder(UUID orderId) {
        Order procesingOrder=getOrderById(orderId)
                .orElseThrow(()-> new IllegalArgumentException("Order Not Found By id"));
        if (!procesingOrder.getStatus().equals(OrderStatus.PENDING)) {
            throw new IllegalArgumentException("The order status must be PENDING for processing.");
        }
        procesingOrder.calculateTotal();
        PaymentRequest paymentRequest = new PaymentRequest(
                orderId,
                procesingOrder.getTotal(),
                "USD"
        );

        String transactionId;
        try {
            transactionId = paymentPort.processPayment(paymentRequest);
        } catch (Exception e) {
            throw new IllegalArgumentException("Payment initiation failed for order " + orderId + ". Reason: " + e.getMessage());
        }
        procesingOrder.setTransactionId(transactionId);
        procesingOrder.switchToWaitingConfirmation();
        return persistence.save(procesingOrder);

    }
    @Override
    public Order updateOrder(UUID id,Long itemId, OrderItem orderItem) {
        Order procesingOrder=getOrderById(id)
                .orElseThrow(()-> new IllegalArgumentException("Order Not Found By id"));
        if(!procesingOrder.getStatus().equals(OrderStatus.PENDING)){
            throw new IllegalArgumentException("The order is no being processing");
        }
        for (OrderItem item: procesingOrder.getItems()){
            if (item.getId().equals(itemId)){
                itemService.updateOrderItem(item.getId(),orderItem);
            }
        }
        return persistence.save(procesingOrder);
    }

    @Override
    public Order acceptOrder(UUID orderId) {
        Order acceptedOrder=getOrderById(orderId)
                .orElseThrow(()-> new IllegalArgumentException("Order Not Found By id"));
        if(!acceptedOrder.getStatus().equals(OrderStatus.ACCEPTED)){
            throw new IllegalArgumentException("The ORder status must be Accepted");
        }
        for (OrderItem item: acceptedOrder.getItems()){
            productPort.decrementStock(item.getProductSku(), item.getQuantity());
        }
        return persistence.save(acceptedOrder);
    }

    @Override
    public void cancelOrder(UUID id) {
        Order existingOrder=getOrderById(id)
                .orElseThrow(()-> new IllegalArgumentException("Order Not Found By id"));
        existingOrder.switchToCanceled();
        for (OrderItem item: existingOrder.getItems()){
            productPort.recoveryStock(item.getProductSku(), item.getQuantity());
        }
        persistence.save(existingOrder);
    }

    @Override
    public Order deleteItem(UUID orderId, Long itemId) {
        Order existingOrder=getOrderById(orderId)
                .orElseThrow(()-> new IllegalArgumentException("Order Not Found By id"));
        for(OrderItem item: existingOrder.getItems()){
            if (item.getId().equals(itemId)){
                itemService.delete(itemId);
            }
        }
        return  persistence.save(existingOrder);
    }

    @Override
    public Optional<Order> getOrderById(UUID id) {
        return persistence.findById(id);
    }
}
